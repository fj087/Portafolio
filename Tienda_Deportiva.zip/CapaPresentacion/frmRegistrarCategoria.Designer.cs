﻿namespace CapaPresentacion
{
    partial class frmRegistrarCategoria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panel1 = new Panel();
            Descripcion = new TextBox();
            Nombre = new TextBox();
            ID = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            Button1 = new Button();
            errorProvider1 = new ErrorProvider(components);
            BtnReg = new Button();
            label8 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(Descripcion);
            panel1.Controls.Add(Nombre);
            panel1.Controls.Add(ID);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Location = new Point(136, 119);
            panel1.Name = "panel1";
            panel1.Size = new Size(401, 141);
            panel1.TabIndex = 1;
            // 
            // Descripcion
            // 
            Descripcion.Location = new Point(152, 85);
            Descripcion.Name = "Descripcion";
            Descripcion.Size = new Size(218, 23);
            Descripcion.TabIndex = 5;
            // 
            // Nombre
            // 
            Nombre.Location = new Point(152, 52);
            Nombre.Name = "Nombre";
            Nombre.Size = new Size(218, 23);
            Nombre.TabIndex = 4;
            // 
            // ID
            // 
            ID.Location = new Point(152, 22);
            ID.Name = "ID";
            ID.Size = new Size(218, 23);
            ID.TabIndex = 3;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(14, 93);
            label4.Name = "label4";
            label4.Size = new Size(69, 15);
            label4.TabIndex = 2;
            label4.Text = "Descripción";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(14, 60);
            label3.Name = "label3";
            label3.Size = new Size(58, 15);
            label3.TabIndex = 1;
            label3.Text = "Categoría";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(14, 20);
            label2.Name = "label2";
            label2.Size = new Size(18, 15);
            label2.TabIndex = 0;
            label2.Text = "ID";
            // 
            // Button1
            // 
            Button1.BackColor = SystemColors.ButtonShadow;
            Button1.Font = new Font("Arial Rounded MT Bold", 12F);
            Button1.Location = new Point(428, 317);
            Button1.Name = "Button1";
            Button1.Size = new Size(109, 52);
            Button1.TabIndex = 2;
            Button1.Text = "Regresar";
            Button1.UseVisualStyleBackColor = false;
            Button1.Click += Button1_Click_1;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // BtnReg
            // 
            BtnReg.BackColor = SystemColors.ButtonShadow;
            BtnReg.Font = new Font("Arial Rounded MT Bold", 12F);
            BtnReg.Location = new Point(136, 317);
            BtnReg.Name = "BtnReg";
            BtnReg.Size = new Size(109, 52);
            BtnReg.TabIndex = 3;
            BtnReg.Text = "Registrar";
            BtnReg.UseVisualStyleBackColor = false;
            BtnReg.Click += BtnReg_Click_1;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.FlatStyle = FlatStyle.Popup;
            label8.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.Highlight;
            label8.Location = new Point(254, 57);
            label8.Name = "label8";
            label8.Size = new Size(170, 18);
            label8.TabIndex = 8;
            label8.Text = "Registrar  Categoría";
            label8.TextAlign = ContentAlignment.TopCenter;
            // 
            // frmRegistrarCategoria
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(691, 573);
            Controls.Add(label8);
            Controls.Add(BtnReg);
            Controls.Add(Button1);
            Controls.Add(panel1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "frmRegistrarCategoria";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Registrar Categoria";
            Load += frmRegistrarCategoria_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel panel1;
        private TextBox Descripcion;
        private TextBox Nombre;
        private TextBox ID;
        private Label label4;
        private Label label3;
        private Label label2;
        private Button Button1;
        private ErrorProvider errorProvider1;
        private Button BtnReg;
        private Label label8;
    }
}