﻿using CapaAccesoDatos;
using CapaEntidades;
using CapaLogicaNegocio;

/* UNED III Cuatrimestre
 * Proyecto 1: Tienda Deportiva
 * Estudiante: Jessenia Fuentes Ruiz
 * Fecha: 06/09/2024
 * */


namespace CapaPresentacion
{
    public partial class frmRegistroArticulo : Form
    {
        public frmRegistroArticulo()
        {
            InitializeComponent();
        }

        private void Button1_Click_1(object sender, EventArgs e)
        {



            try
            {



                Articulos articulos = new Articulos();
                articulos.ID = Convert.ToInt32(textid.Text);
                articulos.Marca = txtmarca.Text;
                articulos.Descripcion = textdescripcion.Text;




                errorProvider1.Clear();
                // Button1.Enabled = false;

                if (string.IsNullOrWhiteSpace(textid.Text) || !textid.Text.All(char.IsDigit))
                {

                    errorProvider1.SetError(textid, "El ID solo debe incluir números");
                    return;
                }
                else
                {
                    errorProvider1.SetError(textid, ""); // Eliminar cualquier error anterior
                }



                if (string.IsNullOrWhiteSpace(txtmarca.Text))
                {


                    errorProvider1.SetError(txtmarca, "El espacio no debe estar en blanco.");
                    return;
                }
                else
                {
                    errorProvider1.SetError(txtmarca, "");
                }


                if (string.IsNullOrWhiteSpace(textdescripcion.Text))
                {


                    errorProvider1.SetError(textdescripcion, "El espacio no debe estar en blanco.");
                    return;
                }
                else
                {
                    errorProvider1.SetError(textdescripcion, "");

                }

                if (comboBoxCatg.SelectedItem == null)
                {
                    errorProvider1.SetError(comboBoxCatg, "Debe seleccionar una categoría.");
                    return;
                }
                else
                {

                    articulos.Nombre = comboBoxCatg.SelectedItem.ToString();
                    errorProvider1.SetError(comboBoxCatg, "");

                }


                if (comboBoxActv.SelectedIndex == null)
                {
                    errorProvider1.SetError(comboBoxActv, "Debe seleccionar una opción.");
                    return;
                }
                else
                {
                    string seleccion = comboBoxActv.SelectedItem.ToString();
                    articulos.Activo = seleccion == "Sí";
                    errorProvider1.SetError(comboBoxActv, "");
                }

                ValidacionArticulo registro = new ValidacionArticulo();
                bool articuloIngresado = registro.CargarArticulos(articulos);


                LimpiarPantalla();
                comboBoxCatg.SelectedIndex = -1;
                comboBoxActv.SelectedIndex = -1;
                Button1.Enabled = true;
            }

            catch (FormatException)
            {
                errorProvider1.SetError(textid, "Debe ingresar un número válido");
                Button1.Enabled = true;
            }

        }


        public void LimpiarPantalla()
        {
            textid.Clear();
            txtmarca.Clear();
            textdescripcion.Clear();
        }

        /// <summary>
        /// Carga las categorías desde la fuente de datos y las agrega en
        /// el combox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmRegistroArticulo_Load(object sender, EventArgs e)
        {


            Categorias[] categorias = RegistroCat.Consultar();

            comboBoxCatg.Items.Clear();

            for (int i = 0; i < categorias.Length; i++)
            {
                if (categorias[i] != null)
                {
                    comboBoxCatg.Items.Add(categorias[i].Nombre);
                }
            }




            //Crea una lista de valores bolenas para combox
            List<String> opcion = new List<String> { "Sí", "No" };
            comboBoxActv.Items.Clear();

            //Asigna la lista como fuente da datos en el combobox 
            comboBoxActv.Items.Add("Sí");
            comboBoxActv.Items.Add("No");


            //Asegura que no hay ninguna opcion seleccionada al cargar la ventana
            comboBoxActv.SelectedIndex = -1;

        }

    

        

        private void Button2_Click_1(object sender, EventArgs e)
        {
            this.Hide();
        }


    }

}