﻿namespace CapaPresentacion
{
    partial class frmRegistroArticulo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panel1 = new Panel();
            comboBoxCatg = new ComboBox();
            comboBoxActv = new ComboBox();
            txtmarca = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textdescripcion = new TextBox();
            textid = new TextBox();
            Button1 = new Button();
            errorProvider1 = new ErrorProvider(components);
            Button2 = new Button();
            label8 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(comboBoxCatg);
            panel1.Controls.Add(comboBoxActv);
            panel1.Controls.Add(txtmarca);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(textdescripcion);
            panel1.Controls.Add(textid);
            panel1.Location = new Point(167, 85);
            panel1.Name = "panel1";
            panel1.Size = new Size(330, 258);
            panel1.TabIndex = 0;
            // 
            // comboBoxCatg
            // 
            comboBoxCatg.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxCatg.FlatStyle = FlatStyle.Flat;
            comboBoxCatg.FormattingEnabled = true;
            comboBoxCatg.Location = new Point(112, 113);
            comboBoxCatg.Name = "comboBoxCatg";
            comboBoxCatg.Size = new Size(159, 23);
            comboBoxCatg.TabIndex = 10;
            // 
            // comboBoxActv
            // 
            comboBoxActv.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxActv.FlatStyle = FlatStyle.Flat;
            comboBoxActv.FormattingEnabled = true;
            comboBoxActv.Location = new Point(112, 195);
            comboBoxActv.Name = "comboBoxActv";
            comboBoxActv.Size = new Size(159, 23);
            comboBoxActv.TabIndex = 9;
            // 
            // txtmarca
            // 
            txtmarca.Location = new Point(112, 152);
            txtmarca.Name = "txtmarca";
            txtmarca.Size = new Size(159, 23);
            txtmarca.TabIndex = 8;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(8, 116);
            label5.Name = "label5";
            label5.Size = new Size(58, 15);
            label5.TabIndex = 7;
            label5.Text = "Categoría";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(8, 81);
            label4.Name = "label4";
            label4.Size = new Size(72, 15);
            label4.TabIndex = 6;
            label4.Text = "Descripción ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(8, 195);
            label3.Name = "label3";
            label3.Size = new Size(41, 15);
            label3.TabIndex = 5;
            label3.Text = "Activo";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(8, 152);
            label2.Name = "label2";
            label2.Size = new Size(40, 15);
            label2.TabIndex = 4;
            label2.Text = "Marca";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(8, 34);
            label1.Name = "label1";
            label1.Size = new Size(18, 15);
            label1.TabIndex = 3;
            label1.Text = "ID";
            // 
            // textdescripcion
            // 
            textdescripcion.Location = new Point(112, 73);
            textdescripcion.Name = "textdescripcion";
            textdescripcion.Size = new Size(159, 23);
            textdescripcion.TabIndex = 1;
            // 
            // textid
            // 
            textid.Location = new Point(112, 34);
            textid.Name = "textid";
            textid.Size = new Size(159, 23);
            textid.TabIndex = 0;
            // 
            // Button1
            // 
            Button1.BackColor = SystemColors.ButtonShadow;
            Button1.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Button1.Location = new Point(140, 386);
            Button1.Name = "Button1";
            Button1.Size = new Size(109, 52);
            Button1.TabIndex = 1;
            Button1.Text = "Regristrar";
            Button1.UseVisualStyleBackColor = false;
            Button1.Click += Button1_Click_1;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // Button2
            // 
            Button2.BackColor = SystemColors.ButtonShadow;
            Button2.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Button2.Location = new Point(425, 386);
            Button2.Name = "Button2";
            Button2.Size = new Size(109, 52);
            Button2.TabIndex = 2;
            Button2.Text = "Regrasar";
            Button2.UseVisualStyleBackColor = false;
            Button2.Click += Button2_Click_1;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.FlatStyle = FlatStyle.Popup;
            label8.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.Highlight;
            label8.Location = new Point(250, 39);
            label8.Name = "label8";
            label8.Size = new Size(154, 18);
            label8.TabIndex = 8;
            label8.Text = "Registrar  Artículo";
            label8.TextAlign = ContentAlignment.TopCenter;
            // 
            // frmRegistroArticulo
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(691, 573);
            Controls.Add(label8);
            Controls.Add(Button2);
            Controls.Add(Button1);
            Controls.Add(panel1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "frmRegistroArticulo";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Registro Articulo";
            Load += frmRegistroArticulo_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textdescripcion;
        private TextBox textid;
        private Label label5;
        private ComboBox comboBoxCatg;
        private ComboBox comboBoxActv;
        private TextBox txtmarca;
        private Button Button1;
        private ErrorProvider errorProvider1;
        private Button Button2;
        private Label label8;
    }
}