﻿using CapaAccesoDatos;
using CapaEntidades;

namespace CapaPresentacion
{
    public partial class dgvConsultaCatg : Form
    {

        public dgvConsultaCatg()
        {
            InitializeComponent();


        }


        public void CargarCategorias(Categorias[] categorias)
        {
            try
            {
                dataGridView1.Rows.Clear();
               // Categorias[] categorias = RegistroCat.Consultar();

              

                    foreach (var categor in categorias)
                    {
                        if (categorias != null)
                        {

                            dataGridView1.Rows.Add(categor.ID, categor.Nombre, categor.Descrip);
                        }

                    }

                }

            
            catch (Exception ex)
            {
                MessageBox.Show("Ocurrió un error: " + ex.Message);
            }


        }


        private void BtnRegesar_Click_1(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void dgvConsultaCatg_Load(object sender, EventArgs e)
        {

        }
    }

}

