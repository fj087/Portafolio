﻿namespace CapaPresentacion
{
    partial class frmConsultaCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            buttRegresar = new Button();
            label8 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5, Column6 });
            dataGridView1.Location = new Point(37, 137);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(608, 150);
            dataGridView1.TabIndex = 0;
            // 
            // Column1
            // 
            Column1.HeaderText = "ID Cliente";
            Column1.Name = "Column1";
            // 
            // Column2
            // 
            Column2.HeaderText = "Nombre";
            Column2.Name = "Column2";
            // 
            // Column3
            // 
            Column3.HeaderText = "Primer Apellido";
            Column3.Name = "Column3";
            // 
            // Column4
            // 
            Column4.HeaderText = "Segundo Apellido";
            Column4.Name = "Column4";
            // 
            // Column5
            // 
            Column5.HeaderText = "Fecha Nacimiento";
            Column5.Name = "Column5";
            // 
            // Column6
            // 
            Column6.HeaderText = "Activo";
            Column6.Name = "Column6";
            // 
            // buttRegresar
            // 
            buttRegresar.BackColor = SystemColors.ButtonShadow;
            buttRegresar.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttRegresar.Location = new Point(470, 357);
            buttRegresar.Name = "buttRegresar";
            buttRegresar.Size = new Size(109, 52);
            buttRegresar.TabIndex = 1;
            buttRegresar.Text = "Regresar";
            buttRegresar.UseVisualStyleBackColor = false;
            buttRegresar.Click += buttRegresar_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.FlatStyle = FlatStyle.Popup;
            label8.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.Highlight;
            label8.Location = new Point(280, 58);
            label8.Name = "label8";
            label8.Size = new Size(146, 18);
            label8.TabIndex = 8;
            label8.Text = "Consultar Cliente";
            label8.TextAlign = ContentAlignment.TopCenter;
            // 
            // frmConsultaCliente
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(691, 473);
            Controls.Add(label8);
            Controls.Add(buttRegresar);
            Controls.Add(dataGridView1);
            Name = "frmConsultaCliente";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Consulta Cliente";
            Load += frmConsultaCliente_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private Button buttRegresar;
        private Label label8;
    }
}