﻿namespace CapaPresentacion
{
    partial class frmConsultarSucursal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            BtnReg = new Button();
            label8 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5, Column6 });
            dataGridView1.Location = new Point(41, 159);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(605, 203);
            dataGridView1.TabIndex = 0;
            // 
            // Column1
            // 
            Column1.HeaderText = "ID Sucursal";
            Column1.Name = "Column1";
            // 
            // Column2
            // 
            Column2.HeaderText = "Nombre";
            Column2.Name = "Column2";
            // 
            // Column3
            // 
            Column3.HeaderText = "Administrador";
            Column3.Name = "Column3";
            // 
            // Column4
            // 
            Column4.HeaderText = "Dirección";
            Column4.Name = "Column4";
            // 
            // Column5
            // 
            Column5.HeaderText = "Teléfono";
            Column5.Name = "Column5";
            // 
            // Column6
            // 
            Column6.HeaderText = "Activo";
            Column6.Name = "Column6";
            // 
            // BtnReg
            // 
            BtnReg.BackColor = SystemColors.ButtonShadow;
            BtnReg.Font = new Font("Arial Rounded MT Bold", 12F);
            BtnReg.Location = new Point(468, 430);
            BtnReg.Name = "BtnReg";
            BtnReg.Size = new Size(109, 52);
            BtnReg.TabIndex = 5;
            BtnReg.Text = "Regresar";
            BtnReg.UseVisualStyleBackColor = false;
            BtnReg.Click += BtnReg_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.FlatStyle = FlatStyle.Popup;
            label8.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.Highlight;
            label8.Location = new Point(262, 78);
            label8.Name = "label8";
            label8.Size = new Size(161, 18);
            label8.TabIndex = 8;
            label8.Text = "Consultar Sucursal";
            label8.TextAlign = ContentAlignment.TopCenter;
            // 
            // frmConsultarSucursal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(691, 573);
            Controls.Add(label8);
            Controls.Add(BtnReg);
            Controls.Add(dataGridView1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "frmConsultarSucursal";
            Text = "Consultar Sucursal";
            Load += frmConsultarSucursal_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private Button BtnReg;
        private Label label8;
    }
}