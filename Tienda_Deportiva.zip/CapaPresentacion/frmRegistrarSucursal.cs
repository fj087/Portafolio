﻿using System;
using CapaEntidades;
using CapaLogicaNegocio;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Controls;
using static System.Runtime.InteropServices.JavaScript.JSType;
using CapaAccesoDatos;
using System.ComponentModel.DataAnnotations;

namespace CapaPresentacion
{
    public partial class frmRegistrarSucursal : Form
    {
        public frmRegistrarSucursal()
        {
            InitializeComponent();
        }


        private void BtnReg_Click(object sender, EventArgs e)
        {

            try
            {
                // Inicializar la nueva instancia de Sucursal
                Sucursal sucursal = new Sucursal();
                sucursal.IdSucursal = int.Parse(textidSucursal.Text);
                sucursal.NombreSucursal = textnombre.Text;          
                sucursal.DireccionSucursal = texdireccion.Text;
                sucursal.TelefoSuculsal = long.Parse(texttelefono.Text);
           

                // Limpiar errores previos
                errorProvider1.Clear();

                // Validar ID de sucursal
                if (string.IsNullOrWhiteSpace(textidSucursal.Text))
                {
                    errorProvider1.SetError(textidSucursal, "El ID no puede estar vacío");
                    return;
                }
                if (!textidSucursal.Text.All(char.IsDigit))
                {
                    errorProvider1.SetError(textidSucursal, "El ID solo debe incluir números");
                    return;
                }


                // Validar nombre de la sucursal
                if (string.IsNullOrWhiteSpace(textnombre.Text))
                {
                    errorProvider1.SetError(textnombre, "El nombre no puede estar vacío");
                    return;
                }
                if (!textnombre.Text.All(c => char.IsLetter(c) || char.IsWhiteSpace(c)))
                {
                    errorProvider1.SetError(textnombre, "El nombre solo debe incluir letras y espacios");
                    return;
                }
               

                // Validar administrador de la sucursal

                if (comboBoxAdministradores.SelectedItem !=null)
                {
                    sucursal.NombreAdmin = comboBoxAdministradores.SelectedItem.ToString();
                   
                }
                else
                {
                    errorProvider1.SetError(comboBoxAdministradores, "Debe seleccionar un administrador.");
                    return;
                }



                // Validar dirección de la sucursal
                if (string.IsNullOrWhiteSpace(texdireccion.Text))
                {
                    errorProvider1.SetError(texdireccion, "La dirección no puede estar vacía");
                    return;
                }


                // Validar teléfono de la sucursal
                if (string.IsNullOrEmpty(texttelefono.Text))
                {
                    errorProvider1.SetError(texttelefono, "El teléfono no puede estar vacío");
                    return;
                }
                if (!texttelefono.Text.All(char.IsDigit))
                {
                    errorProvider1.SetError(texttelefono, "El teléfono debe incluir solo números");
                    return;
                }

                if (texttelefono.Text.Length > 12)
                {
                    errorProvider1.SetError(texttelefono, "Digíte un numero de teléfono válido");
                    return;
                 }

                if (comboBoxActiv.SelectedItem == null)
                {
                    errorProvider1.SetError(comboBoxActiv, "Debe seleccionar una opción,");
                    return;
                }
                else
                {
                    //Convierte el valor seleccionado en un bool
                    string seleccion = comboBoxActiv.SelectedItem.ToString();
                    sucursal.Activo = seleccion == "Sí";
                    
                   errorProvider1.SetError(comboBoxActiv, "");

                }

                

                //Relacion de la capa de negocio para guargar la sucursal
                ValidacionSucursales validacionSucur = new ValidacionSucursales();
                bool registroExito = validacionSucur.IngresarSucursales(sucursal);

                // Si todas las validaciones son correctas, se limpia la pantalla
                LimpiarPantalla();
                comboBoxAdministradores.SelectedIndex = -1;
                comboBoxActiv.SelectedIndex = -1;
                BtnReg.Enabled = true;
            }
            catch (FormatException)
            {
                errorProvider1.SetError(textidSucursal, "Debe ingresar un número válido");
            }


        }


        public void LimpiarPantalla()
        {
            textidSucursal.Clear();
            textnombre.Clear();
            texttelefono.Clear();
            texdireccion.Clear();

        }

        /// <summary>
        /// Método para cargar los combobox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmRegistrarSucursal_Load(object sender, EventArgs e)
        {
            Administrador[] administradores = RegistrarAdministrador.Consultar();

            comboBoxAdministradores.Items.Clear();

            for (int i = 0; i < administradores.Length; i++)
            {
                if (administradores[i] != null)

                {
                    comboBoxAdministradores.Items.Add(administradores[i].NombreAdmin);

                }
            }

            List<string> lista = new List<string> { "Sí", "No"};


            //Asigna la lista como fuente de datos al combobox
            comboBoxActiv.Items.Add("Sí");
            comboBoxActiv.Items.Add("No");


            comboBoxActiv.SelectedIndex = -1;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }



    }
}