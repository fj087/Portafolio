﻿using CapaEntidades;
using CapaAccesoDatos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmConsultaCliente : Form
    {
        public frmConsultaCliente()
        {
            InitializeComponent();
        }

        private void buttRegresar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }


        public void IngresarClientes(Cliente[] clientes)
        {
            try
            {
                dataGridView1.Rows.Clear();
                foreach (var cliente in clientes)

                {
                    if (cliente != null)
                    {
                        dataGridView1.Rows.Add(cliente.ID,
                            cliente.Nombre,
                            cliente.PrimerApellido,
                            cliente.SegundoApellido,
                            cliente.FechaNacimiento.ToString("d"),
                            cliente.Activo);
                    }
                }

            }
            catch (Exception e)
            {
                MessageBox.Show("Ocurrió un error al cargar los artículos: " + e.Message);
                {

                }
            }

        }

        private void frmConsultaCliente_Load(object sender, EventArgs e)
        {

        }
    }
}
