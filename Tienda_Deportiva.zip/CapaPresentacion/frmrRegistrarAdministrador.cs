﻿using CapaLogicaNegocio;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using CapaAccesoDatos;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CapaPresentacion
{
    public partial class frmrRegistrarAdministrador : Form
    {
        public frmrRegistrarAdministrador()
        {
            InitializeComponent();
        }



        private void button2_Click_1(object sender, EventArgs e)
        {



            try
            {
                Administrador administrador = new Administrador();
                administrador.Identificacion = int.Parse(textIdentificacion.Text);
                administrador.NombreAdmin = textNombre.Text;
                administrador.PrimerApellido = textPrimerApelli.Text;
                administrador.SegundoApellido = textSegundoApelli.Text;
                administrador.FechaCumpleaños = fechaNacimiento.Value;
                administrador.FechaIngreso = fechaIngreso.Value.Date;


                // button2.Enabled = false;
                errorProvider1.Clear();

                //Validar Id
                if (string.IsNullOrWhiteSpace(textIdentificacion.Text))
                {
                    textIdentificacion.Focus();
                    errorProvider1.SetError(textIdentificacion, "El espacio no debe estar vacío.");
                    return;
                }
                if (!textIdentificacion.Text.All(char.IsDigit))
                {
                    textIdentificacion.Focus();
                    errorProvider1.SetError(textIdentificacion, "El ID solo debe incluir números");
                    return;
                }
                if (textIdentificacion.Text.Length != 9)
                {
                    errorProvider1.SetError(textIdentificacion, "Debe ingresar 9 dígitos.");
                    return;
                }
                else
                {
                    errorProvider1.SetError(textIdentificacion, "");
                }

                //Validar Nombre
                if (string.IsNullOrEmpty(textNombre.Text))
                {
                    textNombre.Focus();
                    errorProvider1.SetError(textNombre, "El espacio no deber estar vacío");
                    return;
                }
                if (!textNombre.Text.All(char.IsLetter))
                {
                    textNombre.Focus();
                    errorProvider1.SetError(textNombre, "El nombre solo  deber incluir letras");
                    return;
                }
                else
                {
                    errorProvider1.SetError(textNombre, "");
                }

                //Validar Primer Apellido
                if (string.IsNullOrEmpty(textPrimerApelli.Text))
                {
                    textPrimerApelli.Focus();
                    errorProvider1.SetError(textPrimerApelli, "El espacio no deber estar vacío");
                    return;
                }
                if (!textPrimerApelli.Text.All(char.IsLetter))
                {
                    textPrimerApelli.Focus();
                    errorProvider1.SetError(textPrimerApelli, "El nombre solo  deber incluir letras");
                    return;
                }
                else
                {
                    errorProvider1.SetError(textPrimerApelli, "");
                }

                //Validar Segundo Apellido
                if (string.IsNullOrWhiteSpace(textSegundoApelli.Text))
                {
                    textSegundoApelli.Focus();
                    errorProvider1.SetError(textSegundoApelli, "El espacio no deber estar vacío");
                    return;
                }
                if (!textSegundoApelli.Text.All(char.IsLetter))
                {
                    textSegundoApelli.Focus();
                    errorProvider1.SetError(textSegundoApelli, "El nombre solo  deber incluir letras");
                    return;
                }
                else
                {
                    errorProvider1.SetError(textSegundoApelli, "");
                }
                //Valiar Fecha de Nacimiento
                if (fechaNacimiento.Value.Date >= DateTime.Now.Date)
                {
                    fechaNacimiento.Focus();
                    errorProvider1.SetError(fechaNacimiento, "La fecha de nacimiento debe ser anterior a la fecha actual.");
                    return;
                }
                else
                {
                    errorProvider1.SetError(fechaNacimiento, "");
                }
                //Validar Fecha de Ingreso
                if (fechaIngreso.Value.Date <= DateTime.Now.Date)
                {
                    fechaIngreso.Focus();
                    errorProvider1.SetError(fechaIngreso, "La fecha de ingreso no debe ser anterior a la fecha actual");
                    return;
                }
                else
                {
                    errorProvider1.SetError(fechaIngreso, "");
                }


                //Acceso a la capa logica de negocios
                ValidacionAdmin registroAdmin = new ValidacionAdmin();
                bool adminValido = registroAdmin.IngresarAdministradores(administrador);

                LimpiarPantalla();
                button2.Enabled = true;

            }
            catch (FormatException)
            {
                errorProvider1.SetError(textIdentificacion, " un ID valido ");

            }

        }
        /// <summary>
        /// Método para limpiar pantalla 
        /// </summary>
        public void LimpiarPantalla()
        {
            textIdentificacion.Clear();
            textNombre.Clear();
            textPrimerApelli.Clear();
            textSegundoApelli.Clear();
            errorProvider1.Clear();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void frmrRegistrarAdministrador_Load(object sender, EventArgs e)
        {

        }
    }
}

