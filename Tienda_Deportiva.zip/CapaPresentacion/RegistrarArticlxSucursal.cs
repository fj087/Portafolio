﻿using System;
using CapaEntidades;
using CapaAccesoDatos;
using CapaLogicaNegocio;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Controls;
using System.Runtime.Serialization;


namespace CapaPresentacion
{
    public partial class RegistrarArticlxSucursal : Form
    {


        public RegistrarArticlxSucursal()
        {
            InitializeComponent();
        }
        private void RegistrarArticlxSucursal_Load(object sender, EventArgs e)
        {
            CargarSucursal(); 
            CargarArticulos();
        }
        private void BtnRegesar_Click(object sender, EventArgs e)
        {

            if (comboBoxSuculsal.SelectedItem == null)
            {
                MessageBox.Show("Por favor, seleccione una sucursal.");
                return;
            }
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor, seleccione al menos un artículo.");
                return;
            }

            var sucursalSeleccionada = (Sucursal)comboBoxSuculsal.SelectedItem;

            foreach (DataGridViewRow row in dataGridView1.SelectedRows)
            {

                Articulos articuloSeleccionado = (Articulos)row.DataBoundItem;

                if (int.TryParse(textBoxcantidad.Text, out int cantidad) && cantidad > 0)
                {
                    var nuevaAsociacion = new ArticulosxSucursales(sucursalSeleccionada, articuloSeleccionado, cantidad);
                    ValidacionSucurslxArticl validacion = new ValidacionSucurslxArticl();
                    nuevaAsociacion.Cantidad = cantidad; // Asigna la cantidad a la nueva asociación
                    nuevaAsociacion.sucursal = sucursalSeleccionada;
                    nuevaAsociacion.articulos = articuloSeleccionado;


                    // Verificar si la asociación ya existe
                    if (!validacion.IngresaSucurslxArtic(nuevaAsociacion))
                    {
                        MessageBox.Show("La sucursal ya existe para este artículo.");
                        continue; // Continúa con la siguiente iteración si ya existe la asociación
                    }

                    // Intentar registrar la nueva asociación
                    bool ingresoExitoso = RegistroSucursalxArticl.IngresaSucurslxArtic(nuevaAsociacion);

                    if (ingresoExitoso)
                    {
                        MessageBox.Show("Artículo asociado a la sucursal exitosamente.");
                    }

                }
                else
                {
                    MessageBox.Show("Por favor, ingrese una cantidad válida mayor a cero.");
                }
            }

            LimpiarCampos(); // Limpiar campos después de procesar
        }


        private void LimpiarCampos()
        {
            comboBoxSuculsal.SelectedIndex = -1;

            textBoxcantidad.Clear();

        }

        public void CargarArticulos()
        {
            dataGridView1.Rows.Clear();

            try
            {
                Articulos[] articulos = RegistrarArticulo.Consultar();

                if (articulos != null && articulos.Length > 0)
                {
                    foreach (var articulo in articulos)
                    {
                        if (articulo.Activo)
                        {
                            dataGridView1.Rows.Add(articulo.ID, articulo.Descripcion, articulo.Nombre, articulo.Marca);
                        }
                    }
                    dataGridView1.MultiSelect = true; // Permitir varias selección
                    dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                }            


            }
            catch (Exception ex)
            {
                MessageBox.Show("No hay artículos registrados.");
            }
        }
        private void CargarSucursal()
        {
            comboBoxSuculsal.Items.Clear(); // Limpiar el ComboBox antes de cargar nuevos elementos

            try
            {
                Sucursal[] sucursales = RegistroSucursal.Consultar();

                if (sucursales != null && sucursales.Length > 0)
                {
                    foreach (var sucursal in sucursales)
                    {
                        if (sucursal.Activo)
                        {
                            comboBoxSuculsal.Items.Add(sucursal); // Agregar el objeto sucursal
                        }
                    }

                    
                }
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("No hay sucursales registradas.");
            }
        }

      

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }



}
