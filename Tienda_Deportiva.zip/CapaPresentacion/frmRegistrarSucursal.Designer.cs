﻿namespace CapaPresentacion
{
    partial class frmRegistrarSucursal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panel1 = new Panel();
            comboBoxActiv = new ComboBox();
            comboBoxAdministradores = new ComboBox();
            texttelefono = new TextBox();
            texdireccion = new TextBox();
            textnombre = new TextBox();
            textidSucursal = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            label7 = new Label();
            BtnReg = new Button();
            button1 = new Button();
            errorProvider1 = new ErrorProvider(components);
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(comboBoxActiv);
            panel1.Controls.Add(comboBoxAdministradores);
            panel1.Controls.Add(texttelefono);
            panel1.Controls.Add(texdireccion);
            panel1.Controls.Add(textnombre);
            panel1.Controls.Add(textidSucursal);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(156, 65);
            panel1.Name = "panel1";
            panel1.Size = new Size(363, 313);
            panel1.TabIndex = 0;
            // 
            // comboBoxActiv
            // 
            comboBoxActiv.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxActiv.FlatStyle = FlatStyle.Flat;
            comboBoxActiv.FormattingEnabled = true;
            comboBoxActiv.Location = new Point(169, 247);
            comboBoxActiv.Name = "comboBoxActiv";
            comboBoxActiv.Size = new Size(140, 23);
            comboBoxActiv.TabIndex = 12;
            // 
            // comboBoxAdministradores
            // 
            comboBoxAdministradores.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxAdministradores.FlatStyle = FlatStyle.Flat;
            comboBoxAdministradores.FormattingEnabled = true;
            comboBoxAdministradores.Location = new Point(169, 128);
            comboBoxAdministradores.Name = "comboBoxAdministradores";
            comboBoxAdministradores.Size = new Size(140, 23);
            comboBoxAdministradores.TabIndex = 11;
            // 
            // texttelefono
            // 
            texttelefono.Location = new Point(169, 201);
            texttelefono.Name = "texttelefono";
            texttelefono.Size = new Size(140, 23);
            texttelefono.TabIndex = 9;
            // 
            // texdireccion
            // 
            texdireccion.Location = new Point(169, 165);
            texdireccion.Name = "texdireccion";
            texdireccion.Size = new Size(140, 23);
            texdireccion.TabIndex = 8;
            // 
            // textnombre
            // 
            textnombre.Location = new Point(169, 79);
            textnombre.Name = "textnombre";
            textnombre.Size = new Size(140, 23);
            textnombre.TabIndex = 6;
            // 
            // textidSucursal
            // 
            textidSucursal.Location = new Point(169, 46);
            textidSucursal.Name = "textidSucursal";
            textidSucursal.Size = new Size(140, 23);
            textidSucursal.TabIndex = 5;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(30, 247);
            label6.Name = "label6";
            label6.Size = new Size(41, 15);
            label6.TabIndex = 4;
            label6.Text = "Activo";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(30, 209);
            label5.Name = "label5";
            label5.Size = new Size(52, 15);
            label5.TabIndex = 1;
            label5.Text = "Teléfono";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(30, 173);
            label4.Name = "label4";
            label4.Size = new Size(57, 15);
            label4.TabIndex = 3;
            label4.Text = "Dirección";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(30, 136);
            label3.Name = "label3";
            label3.Size = new Size(83, 15);
            label3.TabIndex = 2;
            label3.Text = "Administrador";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(30, 92);
            label2.Name = "label2";
            label2.Size = new Size(51, 15);
            label2.TabIndex = 1;
            label2.Text = "Nombre";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(30, 54);
            label1.Name = "label1";
            label1.Size = new Size(65, 15);
            label1.TabIndex = 0;
            label1.Text = "ID Sucursal";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.FlatStyle = FlatStyle.Flat;
            label7.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.Highlight;
            label7.Location = new Point(266, 25);
            label7.Name = "label7";
            label7.Size = new Size(162, 18);
            label7.TabIndex = 1;
            label7.Text = "Registrar Sucursal ";
            label7.TextAlign = ContentAlignment.TopCenter;
            // 
            // BtnReg
            // 
            BtnReg.BackColor = SystemColors.ButtonShadow;
            BtnReg.Font = new Font("Arial Rounded MT Bold", 12F);
            BtnReg.Location = new Point(156, 409);
            BtnReg.Name = "BtnReg";
            BtnReg.Size = new Size(109, 52);
            BtnReg.TabIndex = 4;
            BtnReg.Text = "Registrar";
            BtnReg.UseVisualStyleBackColor = false;
            BtnReg.Click += BtnReg_Click;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ButtonShadow;
            button1.Font = new Font("Arial Rounded MT Bold", 12F);
            button1.Location = new Point(423, 409);
            button1.Name = "button1";
            button1.Size = new Size(109, 52);
            button1.TabIndex = 5;
            button1.Text = "Regresar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // frmRegistrarSucursal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(691, 573);
            Controls.Add(button1);
            Controls.Add(BtnReg);
            Controls.Add(label7);
            Controls.Add(panel1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "frmRegistrarSucursal";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Registrar Sucursal";
            Load += frmRegistrarSucursal_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox texttelefono;
        private TextBox texdireccion;
        private TextBox textnombre;
        private TextBox textidSucursal;
        private Label label6;
        private Label label5;
        private Label label7;
        private Button BtnReg;
        private Button button1;
        private ErrorProvider errorProvider1;
        private ComboBox comboBoxAdministradores;
        private ComboBox comboBoxActiv;
    }
}