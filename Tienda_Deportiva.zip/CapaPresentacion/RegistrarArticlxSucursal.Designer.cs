﻿namespace CapaPresentacion
{
    partial class RegistrarArticlxSucursal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label2 = new Label();
            panel1 = new Panel();
            textBoxcantidad = new TextBox();
            label3 = new Label();
            comboBoxSuculsal = new ComboBox();
            BtnRisgistar = new Button();
            errorProvider1 = new ErrorProvider(components);
            dataGridView1 = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            button1 = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(27, 36);
            label2.Name = "label2";
            label2.Size = new Size(51, 15);
            label2.TabIndex = 3;
            label2.Text = "Sucursal";
            // 
            // panel1
            // 
            panel1.Controls.Add(textBoxcantidad);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(comboBoxSuculsal);
            panel1.Controls.Add(label2);
            panel1.Location = new Point(35, 60);
            panel1.Name = "panel1";
            panel1.Size = new Size(491, 107);
            panel1.TabIndex = 0;
            // 
            // textBoxcantidad
            // 
            textBoxcantidad.Location = new Point(345, 28);
            textBoxcantidad.Name = "textBoxcantidad";
            textBoxcantidad.Size = new Size(121, 23);
            textBoxcantidad.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(272, 31);
            label3.Name = "label3";
            label3.Size = new Size(55, 15);
            label3.TabIndex = 6;
            label3.Text = "Cantidad";
            // 
            // comboBoxSuculsal
            // 
            comboBoxSuculsal.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxSuculsal.FlatStyle = FlatStyle.Flat;
            comboBoxSuculsal.FormattingEnabled = true;
            comboBoxSuculsal.Location = new Point(96, 33);
            comboBoxSuculsal.Name = "comboBoxSuculsal";
            comboBoxSuculsal.Size = new Size(121, 23);
            comboBoxSuculsal.TabIndex = 4;
            // 
            // BtnRisgistar
            // 
            BtnRisgistar.BackColor = SystemColors.ButtonShadow;
            BtnRisgistar.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnRisgistar.Location = new Point(81, 364);
            BtnRisgistar.Name = "BtnRisgistar";
            BtnRisgistar.Size = new Size(109, 52);
            BtnRisgistar.TabIndex = 2;
            BtnRisgistar.Text = "Registrar";
            BtnRisgistar.UseVisualStyleBackColor = false;
            BtnRisgistar.Click += BtnRegesar_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4 });
            dataGridView1.Location = new Point(35, 173);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(442, 168);
            dataGridView1.TabIndex = 3;
            // 
            // Column1
            // 
            Column1.HeaderText = "ID";
            Column1.Name = "Column1";
            // 
            // Column2
            // 
            Column2.HeaderText = "Descripción";
            Column2.Name = "Column2";
            // 
            // Column3
            // 
            Column3.HeaderText = "Categoría";
            Column3.Name = "Column3";
            // 
            // Column4
            // 
            Column4.HeaderText = "Marca";
            Column4.Name = "Column4";
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ButtonShadow;
            button1.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(451, 364);
            button1.Name = "button1";
            button1.Size = new Size(109, 52);
            button1.TabIndex = 4;
            button1.Text = "Regresar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // RegistrarArticlxSucursal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(691, 450);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Controls.Add(BtnRisgistar);
            Controls.Add(panel1);
            Name = "RegistrarArticlxSucursal";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Registrar ArticuloxSucursal";
            Load += RegistrarArticlxSucursal_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Label label2;
        private Panel panel1;
        private ComboBox comboBoxSuculsal;
        private Button BtnRisgistar;
        private ErrorProvider errorProvider1;
        private TextBox textBoxcantidad;
        private Label label3;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private Button button1;
    }
}