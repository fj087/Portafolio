﻿using CapaEntidades;
using CapaLogicaNegocio;

namespace CapaPresentacion
{
    public partial class frmRegistrarCategoria : Form
    {


        public frmRegistrarCategoria()
        {
            InitializeComponent();


        }


        private void Button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }


        private void BtnReg_Click_1(object sender, EventArgs e)
        {


            try
            {
                Categorias categorias = new Categorias();
                categorias.ID = int.Parse(ID.Text);
                categorias.Nombre = Nombre.Text;
                categorias.Descrip = Descripcion.Text;




                // Limpiar cualquier mensaje de error antes de comenzar la validación
                errorProvider1.Clear();
                BtnReg.Enabled = false;


                // Validar lo ingresado por el usuario
                if (!string.IsNullOrEmpty(ID.Text))
                {
                    if (!ID.Text.All(char.IsDigit))
                    {
                        errorProvider1.SetError(ID, "El ID solo debe incluir números");
                        return;
                    }
                    else
                    {
                        errorProvider1.SetError(ID, ""); // Eliminar cualquier error anterior
                    }
                }
                else
                {
                    errorProvider1.SetError(ID, "El ID no puede estar vacío");
                    return;
                }


                if (!string.IsNullOrWhiteSpace(Nombre.Text))
                {
                    if (!Nombre.Text.All(char.IsLetter))
                    {
                        errorProvider1.SetError(Nombre, "El nombre no debe incluir números");
                        return;
                    }
                    else
                    {
                        errorProvider1.SetError(Nombre, "");
                    }
                }
                else
                {
                    errorProvider1.SetError(Nombre, "El nombre no puede estar vacío");
                    return;
                }


                if (!string.IsNullOrEmpty(Descripcion.Text))
                {
                    if (!Descripcion.Text.All(char.IsLetter))
                    {
                        errorProvider1.SetError(Descripcion, "La descripción debe incluir solo letras");
                        return;
                    }
                    else
                    {
                        errorProvider1.SetError(Descripcion, "");
                    }
                }
                else
                {
                    errorProvider1.SetError(Descripcion, "La descripción no puede estar vacía");
                    return;
                }

                //Logica de negocio para guardar la categoria
                ValidacionCateg registroVild = new ValidacionCateg();
                bool categIngresada = registroVild.CargarCategorias(categorias);

                LimpiarPantalla(); // Limpiar los campo
                BtnReg.Enabled = true;


            }
            catch (FormatException)
            {
                errorProvider1.SetError(ID, "Debe ingresar un número válido");
            }


        }


        public void LimpiarPantalla()
        {
            ID.Clear();
            Nombre.Clear();
            Descripcion.Clear();
            errorProvider1.Clear();


        }


        private void Button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void frmRegistrarCategoria_Load(object sender, EventArgs e)
        {

        }
    }
}

