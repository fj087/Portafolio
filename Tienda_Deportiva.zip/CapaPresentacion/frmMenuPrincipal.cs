﻿using CapaAccesoDatos;
using CapaEntidades;
using CapaLogicaNegocio;
using System.Windows.Forms;


namespace CapaPresentacion
{
    public partial class frmMenuPrincipal : Form
    {


        public frmMenuPrincipal()
        {
            InitializeComponent();
        }



        private void categoíaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void consultarCategoríaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //  Obtener las categorías desde el arreglo en RegistroCat  CapaDatos
            Categorias[] categorias = RegistroCat.Consultar();
            if (categorias == null || categorias.All(a => a == null))
            {
                MessageBox.Show(" No hay categorías para mostrar.");
                return;
            }
            // Crear una nueva ventana para mostrar las categorías que tiene relación con la capa de datos
            dgvConsultaCatg ventanaRegistroCat = new dgvConsultaCatg();

            // Cargar las categorías en la nueva ventana
            ventanaRegistroCat.CargarCategorias(categorias);

            // Mostrar la ventana de consulta
            ventanaRegistroCat.ShowDialog();
        }

        private void registrarArtículoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmRegistroArticulo ventanafrmRegistroArticulo = new frmRegistroArticulo();

            ventanafrmRegistroArticulo.ShowDialog();
        }


        private void registrarCategoríaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmRegistrarCategoria ventanaRegistrarCategoria = new frmRegistrarCategoria();


            ventanaRegistrarCategoria.ShowDialog();
        }

        private void consultarArtículoToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Articulos[] articulos = RegistrarArticulo.Consultar();

            if (articulos == null || articulos.All(a => a == null))
            {
                MessageBox.Show("No hay artículos para mostrar.");
                return;
            }
            frmConsultarArticulo ventanaConsultarArticulos = new frmConsultarArticulo();
            ventanaConsultarArticulos.CargarArticulos(articulos);  // Cargar los artículos aquí
            ventanaConsultarArticulos.ShowDialog();
        }

        private void menuStrip2_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void registrarAdmistradorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmrRegistrarAdministrador ventanaRegistroAdmin = new frmrRegistrarAdministrador();
            ventanaRegistroAdmin.ShowDialog();
        }

        private void consultarAdministradoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Administrador[] administradors = RegistrarAdministrador.Consultar();
            if (administradors == null || administradors.All(a => a == null))
            {
                MessageBox.Show("No hay registro de administradores.");
                return;
            }

            frmConsultarArministrador ventanafrmrConsultarArministrador = new frmConsultarArministrador();
            ventanafrmrConsultarArministrador.IngresarAdministradores(administradors);
            ventanafrmrConsultarArministrador.ShowDialog();
        }

        private void registrarSucursalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmRegistrarSucursal ventanafrmRegistrarSucursal = new frmRegistrarSucursal();
            ventanafrmRegistrarSucursal.ShowDialog();
        }



        private void consultarSucursalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sucursal[] sucursal = RegistroSucursal.Consultar();
            if (sucursal == null || sucursal.All(a => a == null))
            {
                MessageBox.Show("No hay registro de sucursales.");
                return;
            }

            frmConsultarSucursal ventanafrmConsultarSucursal = new frmConsultarSucursal();
            ventanafrmConsultarSucursal.IngresarSucursales(sucursal);
            ventanafrmConsultarSucursal.ShowDialog();
        }

        private void registrarClienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmRegistrarCliente ventanafrmRegistrarCliente = new frmRegistrarCliente();
            ventanafrmRegistrarCliente.ShowDialog();
        }

        private void consultarClienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Cliente[] clientes = RegistroCliente.Consultar();

            frmConsultaCliente ventanafrmConsultaCliente = new frmConsultaCliente();
            ventanafrmConsultaCliente.IngresarClientes(clientes);
            ventanafrmConsultaCliente.ShowDialog();
        }

      

        private void consultarArticuloPorSucursalToolStripMenuItem_Click(object sender, EventArgs e)
        {
           

            RegistrarArticlxSucursal registrarArticlxSucursal = new RegistrarArticlxSucursal();
            registrarArticlxSucursal.ShowDialog();
        }

        private void consultarArticuloPorSucursalToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ArticulosxSucursales[] articulosxSucursales = RegistroSucursalxArticl.Consultar();


            frmConsultarArticlxSucursal frmConsultarArticlxSucursal = new frmConsultarArticlxSucursal();
            
            frmConsultarArticlxSucursal.IngresaSucurslxArtic(articulosxSucursales);
            frmConsultarArticlxSucursal.ShowDialog();

        }
    }
}