﻿using CapaAccesoDatos;
using CapaEntidades;
using CapaLogicaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmRegistrarCliente : Form
    {
        public frmRegistrarCliente()
        {
            InitializeComponent();
        }

        private void frmRegistrarCliente_Load(object sender, EventArgs e)
        {
            List<string> list = new List<string> { "Sí", "No" };

            if (list != null)
            {
                comboBoxActivo.DataSource = list;
            }

            comboBoxActivo.SelectedIndex = -1;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {

                Cliente cliente = new Cliente();
               
                cliente.Nombre = textnombre.Text;
                cliente.PrimerApellido = textprimerApellid.Text;
                cliente.SegundoApellido = textsegundoApellid.Text;
                cliente.FechaNacimiento = dateTimeFechaNacimiento.Value;
               

                errorProvider1.Clear();
                
                //Validar Id
                if (string.IsNullOrEmpty(texid.Text))
                {
                    texid.Focus();
                    errorProvider1.SetError(texid, "El ID no debe estar vació.");
                    return;
                }
                if (!texid.Text.All(char.IsDigit))
                {
                    texid.Focus();
                    errorProvider1.SetError(texid, "El ID debe contener solo numeros.");
                    return;
                }

                else
                {
                    cliente.ID = int.Parse(texid.Text);
                    errorProvider1.SetError(texid, "");
                }


                //Validar Nombre
                if (string.IsNullOrWhiteSpace(textnombre.Text))
                {
                    textnombre.Focus();
                    errorProvider1.SetError(textnombre, "El nombre no debe estar vació.");
                    return;
                }
                if (!textnombre.Text.All(char.IsLetter))
                {
                    textnombre.Focus();
                    errorProvider1.SetError(textnombre, "El nombre no debe contener solo letras.");
                    return;
                }

                else
                {
                    errorProvider1.SetError(textnombre, "");
                }
                //Validar Primer Apellido 
                if (string.IsNullOrWhiteSpace(textprimerApellid.Text))
                {
                    textprimerApellid.Focus();
                    errorProvider1.SetError(textprimerApellid, "El espacio no debe estar vació.");
                    return;
                }
                if (!textprimerApellid.Text.All(char.IsLetter))
                {
                    textprimerApellid.Focus();
                    errorProvider1.SetError(textprimerApellid, "El apellido solo debe incluir letras no debe estar vació.");
                    return;
                }
                else
                {

                    errorProvider1.SetError(textprimerApellid, "");
                }

                //Validar Segundo Apellio 
                if (string.IsNullOrWhiteSpace(textsegundoApellid.Text))
                {
                    textsegundoApellid.Focus();
                    errorProvider1.SetError(textsegundoApellid, "El espacio no debe estar vació.");
                    return;
                }
                if (!textsegundoApellid.Text.All(char.IsLetter))
                {
                    textsegundoApellid.Focus();
                    errorProvider1.SetError(textsegundoApellid, "El apellido solo debe incluir letras no debe estar vació.");
                    return;
                }
                else
                {

                    errorProvider1.SetError(textsegundoApellid, "");
                }

                //Valiar Fecha de Nacimiento
                if (dateTimeFechaNacimiento.Value.Date >= DateTime.Now.Date)
                {
                    dateTimeFechaNacimiento.Focus();
                    errorProvider1.SetError(dateTimeFechaNacimiento, "La fecha de nacimiento debe ser anterior a la fecha actual.");
                    return;
                }
                else
                {
                    errorProvider1.SetError(dateTimeFechaNacimiento, "");
                }

                //Validación de Activo
                if (comboBoxActivo.SelectedItem == null)
                {
                    errorProvider1.SetError(comboBoxActivo, "Debe escoger una opción");
                    return;
                }
                else
                {
                    //Convierte el valor seleccionado en un bool
                    string list = comboBoxActivo.SelectedIndex.ToString();
                    bool Activo = list == "Sí";
                    errorProvider1.SetError(comboBoxActivo, "");
                }
                //Relacion con la capa de negocio para validar la información
                ValidarCliente validarCliene = new ValidarCliente();
                bool IngreseCliente = validarCliene.IngresarClientes(cliente);


                LimpiaPantalla();
                comboBoxActivo.SelectedIndex = -1;
            }
            catch (Exception )
            {
                MessageBox.Show("Por favor verifique que no hay espacios en blanco.");
            }
        }

        public void LimpiaPantalla()
        {
            texid.Clear();
            textnombre.Clear();
            textprimerApellid.Clear();
            textsegundoApellid.Clear();
            
        }

        private void buttRegresar_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

       
    }
}
