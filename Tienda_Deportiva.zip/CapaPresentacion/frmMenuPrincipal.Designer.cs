﻿namespace CapaPresentacion
{
    partial class frmMenuPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            menuStrip2 = new MenuStrip();
            categoíaToolStripMenuItem = new ToolStripMenuItem();
            registrarCategoríaToolStripMenuItem = new ToolStripMenuItem();
            consultarCategoríaToolStripMenuItem = new ToolStripMenuItem();
            arctículoToolStripMenuItem = new ToolStripMenuItem();
            registrarArtículoToolStripMenuItem = new ToolStripMenuItem();
            consultarArtículoToolStripMenuItem = new ToolStripMenuItem();
            admistradorToolStripMenuItem = new ToolStripMenuItem();
            registrarAdmistradorToolStripMenuItem = new ToolStripMenuItem();
            consultarAdministradoresToolStripMenuItem = new ToolStripMenuItem();
            sucursalToolStripMenuItem = new ToolStripMenuItem();
            registrarSucursalToolStripMenuItem = new ToolStripMenuItem();
            consultarSucursalToolStripMenuItem = new ToolStripMenuItem();
            clienteToolStripMenuItem = new ToolStripMenuItem();
            registrarClienteToolStripMenuItem = new ToolStripMenuItem();
            consultarClienteToolStripMenuItem = new ToolStripMenuItem();
            registroArticuloPorSucursalToolStripMenuItem = new ToolStripMenuItem();
            consultarArticuloPorSucursalToolStripMenuItem = new ToolStripMenuItem();
            consultarArticuloPorSucursalToolStripMenuItem1 = new ToolStripMenuItem();
            menuStrip2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.MenuHighlight;
            label1.Location = new Point(227, 152);
            label1.Name = "label1";
            label1.Size = new Size(202, 22);
            label1.TabIndex = 1;
            label1.Text = "TIENDA DEPORTIVA";
            // 
            // menuStrip2
            // 
            menuStrip2.Items.AddRange(new ToolStripItem[] { categoíaToolStripMenuItem, arctículoToolStripMenuItem, admistradorToolStripMenuItem, sucursalToolStripMenuItem, clienteToolStripMenuItem, registroArticuloPorSucursalToolStripMenuItem });
            menuStrip2.Location = new Point(0, 0);
            menuStrip2.Name = "menuStrip2";
            menuStrip2.Size = new Size(691, 24);
            menuStrip2.TabIndex = 2;
            menuStrip2.Text = "menuStrip2";
            menuStrip2.ItemClicked += menuStrip2_ItemClicked;
            // 
            // categoíaToolStripMenuItem
            // 
            categoíaToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { registrarCategoríaToolStripMenuItem, consultarCategoríaToolStripMenuItem });
            categoíaToolStripMenuItem.Name = "categoíaToolStripMenuItem";
            categoíaToolStripMenuItem.Size = new Size(69, 20);
            categoíaToolStripMenuItem.Text = "Categoía ";
            categoíaToolStripMenuItem.Click += categoíaToolStripMenuItem_Click;
            // 
            // registrarCategoríaToolStripMenuItem
            // 
            registrarCategoríaToolStripMenuItem.Name = "registrarCategoríaToolStripMenuItem";
            registrarCategoríaToolStripMenuItem.Size = new Size(179, 22);
            registrarCategoríaToolStripMenuItem.Text = "Registrar Categoría";
            registrarCategoríaToolStripMenuItem.Click += registrarCategoríaToolStripMenuItem_Click;
            // 
            // consultarCategoríaToolStripMenuItem
            // 
            consultarCategoríaToolStripMenuItem.Name = "consultarCategoríaToolStripMenuItem";
            consultarCategoríaToolStripMenuItem.Size = new Size(179, 22);
            consultarCategoríaToolStripMenuItem.Text = "Consultar Categoría";
            consultarCategoríaToolStripMenuItem.Click += consultarCategoríaToolStripMenuItem_Click;
            // 
            // arctículoToolStripMenuItem
            // 
            arctículoToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { registrarArtículoToolStripMenuItem, consultarArtículoToolStripMenuItem });
            arctículoToolStripMenuItem.Name = "arctículoToolStripMenuItem";
            arctículoToolStripMenuItem.Size = new Size(67, 20);
            arctículoToolStripMenuItem.Text = "Arctículo";
            // 
            // registrarArtículoToolStripMenuItem
            // 
            registrarArtículoToolStripMenuItem.Name = "registrarArtículoToolStripMenuItem";
            registrarArtículoToolStripMenuItem.Size = new Size(167, 22);
            registrarArtículoToolStripMenuItem.Text = "Registrar Artículo";
            registrarArtículoToolStripMenuItem.Click += registrarArtículoToolStripMenuItem_Click;
            // 
            // consultarArtículoToolStripMenuItem
            // 
            consultarArtículoToolStripMenuItem.Name = "consultarArtículoToolStripMenuItem";
            consultarArtículoToolStripMenuItem.Size = new Size(167, 22);
            consultarArtículoToolStripMenuItem.Text = "ConsultarArtículo";
            consultarArtículoToolStripMenuItem.Click += consultarArtículoToolStripMenuItem_Click;
            // 
            // admistradorToolStripMenuItem
            // 
            admistradorToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { registrarAdmistradorToolStripMenuItem, consultarAdministradoresToolStripMenuItem });
            admistradorToolStripMenuItem.Name = "admistradorToolStripMenuItem";
            admistradorToolStripMenuItem.Size = new Size(85, 20);
            admistradorToolStripMenuItem.Text = "Admistrador";
            // 
            // registrarAdmistradorToolStripMenuItem
            // 
            registrarAdmistradorToolStripMenuItem.Name = "registrarAdmistradorToolStripMenuItem";
            registrarAdmistradorToolStripMenuItem.Size = new Size(215, 22);
            registrarAdmistradorToolStripMenuItem.Text = "Registrar Admistrador";
            registrarAdmistradorToolStripMenuItem.Click += registrarAdmistradorToolStripMenuItem_Click;
            // 
            // consultarAdministradoresToolStripMenuItem
            // 
            consultarAdministradoresToolStripMenuItem.Name = "consultarAdministradoresToolStripMenuItem";
            consultarAdministradoresToolStripMenuItem.Size = new Size(215, 22);
            consultarAdministradoresToolStripMenuItem.Text = "Consultar Administradores";
            consultarAdministradoresToolStripMenuItem.Click += consultarAdministradoresToolStripMenuItem_Click;
            // 
            // sucursalToolStripMenuItem
            // 
            sucursalToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { registrarSucursalToolStripMenuItem, consultarSucursalToolStripMenuItem });
            sucursalToolStripMenuItem.Name = "sucursalToolStripMenuItem";
            sucursalToolStripMenuItem.Size = new Size(63, 20);
            sucursalToolStripMenuItem.Text = "Sucursal";
            // 
            // registrarSucursalToolStripMenuItem
            // 
            registrarSucursalToolStripMenuItem.Name = "registrarSucursalToolStripMenuItem";
            registrarSucursalToolStripMenuItem.Size = new Size(172, 22);
            registrarSucursalToolStripMenuItem.Text = "Registrar Sucursal";
            registrarSucursalToolStripMenuItem.Click += registrarSucursalToolStripMenuItem_Click;
            // 
            // consultarSucursalToolStripMenuItem
            // 
            consultarSucursalToolStripMenuItem.Name = "consultarSucursalToolStripMenuItem";
            consultarSucursalToolStripMenuItem.Size = new Size(172, 22);
            consultarSucursalToolStripMenuItem.Text = "Consultar Sucursal";
            consultarSucursalToolStripMenuItem.Click += consultarSucursalToolStripMenuItem_Click;
            // 
            // clienteToolStripMenuItem
            // 
            clienteToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { registrarClienteToolStripMenuItem, consultarClienteToolStripMenuItem });
            clienteToolStripMenuItem.Name = "clienteToolStripMenuItem";
            clienteToolStripMenuItem.Size = new Size(56, 20);
            clienteToolStripMenuItem.Text = "Cliente";
            // 
            // registrarClienteToolStripMenuItem
            // 
            registrarClienteToolStripMenuItem.Name = "registrarClienteToolStripMenuItem";
            registrarClienteToolStripMenuItem.Size = new Size(165, 22);
            registrarClienteToolStripMenuItem.Text = "Registrar Cliente";
            registrarClienteToolStripMenuItem.Click += registrarClienteToolStripMenuItem_Click;
            // 
            // consultarClienteToolStripMenuItem
            // 
            consultarClienteToolStripMenuItem.Name = "consultarClienteToolStripMenuItem";
            consultarClienteToolStripMenuItem.Size = new Size(165, 22);
            consultarClienteToolStripMenuItem.Text = "Consultar Cliente";
            consultarClienteToolStripMenuItem.Click += consultarClienteToolStripMenuItem_Click;
            // 
            // registroArticuloPorSucursalToolStripMenuItem
            // 
            registroArticuloPorSucursalToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { consultarArticuloPorSucursalToolStripMenuItem, consultarArticuloPorSucursalToolStripMenuItem1 });
            registroArticuloPorSucursalToolStripMenuItem.Name = "registroArticuloPorSucursalToolStripMenuItem";
            registroArticuloPorSucursalToolStripMenuItem.Size = new Size(175, 20);
            registroArticuloPorSucursalToolStripMenuItem.Text = "Registro Articulo por Sucursal";
         
            // 
            // consultarArticuloPorSucursalToolStripMenuItem
            // 
            consultarArticuloPorSucursalToolStripMenuItem.Name = "consultarArticuloPorSucursalToolStripMenuItem";
            consultarArticuloPorSucursalToolStripMenuItem.Size = new Size(238, 22);
            consultarArticuloPorSucursalToolStripMenuItem.Text = "Registro Articulo por Sucursal";
            consultarArticuloPorSucursalToolStripMenuItem.Click += consultarArticuloPorSucursalToolStripMenuItem_Click;
            // 
            // consultarArticuloPorSucursalToolStripMenuItem1
            // 
            consultarArticuloPorSucursalToolStripMenuItem1.Name = "consultarArticuloPorSucursalToolStripMenuItem1";
            consultarArticuloPorSucursalToolStripMenuItem1.Size = new Size(238, 22);
            consultarArticuloPorSucursalToolStripMenuItem1.Text = "Consultar Articulo por Sucursal";
            consultarArticuloPorSucursalToolStripMenuItem1.Click += consultarArticuloPorSucursalToolStripMenuItem1_Click;
            // 
            // frmMenuPrincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(691, 473);
            Controls.Add(label1);
            Controls.Add(menuStrip2);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "frmMenuPrincipal";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Inicio";
       
            menuStrip2.ResumeLayout(false);
            menuStrip2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private MenuStrip menuStrip2;
        private ToolStripMenuItem categoíaToolStripMenuItem;
        private ToolStripMenuItem registrarCategoríaToolStripMenuItem;
        private ToolStripMenuItem consultarCategoríaToolStripMenuItem;
        private ToolStripMenuItem arctículoToolStripMenuItem;
        private ToolStripMenuItem registrarArtículoToolStripMenuItem;
        private ToolStripMenuItem consultarArtículoToolStripMenuItem;
        private ToolStripMenuItem admistradorToolStripMenuItem;
        private ToolStripMenuItem registrarAdmistradorToolStripMenuItem;
        private ToolStripMenuItem consultarAdministradoresToolStripMenuItem;
        private ToolStripMenuItem sucursalToolStripMenuItem;
        private ToolStripMenuItem registrarSucursalToolStripMenuItem;
        private ToolStripMenuItem consultarSucursalToolStripMenuItem;
        private ToolStripMenuItem clienteToolStripMenuItem;
        private ToolStripMenuItem registrarClienteToolStripMenuItem;
        private ToolStripMenuItem consultarClienteToolStripMenuItem;
        private ToolStripMenuItem registroArticuloPorSucursalToolStripMenuItem;
        private ToolStripMenuItem consultarArticuloPorSucursalToolStripMenuItem;
        private ToolStripMenuItem consultarArticuloPorSucursalToolStripMenuItem1;
    }
}