﻿using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmConsultarArticlxSucursal : Form
    {
        public frmConsultarArticlxSucursal()
        {
            InitializeComponent();
        }

        private void frmConsultarArticlxSucursal_Load(object sender, EventArgs e)
        {

        }
        public void IngresaSucurslxArtic(ArticulosxSucursales[] nuevaAsociacion)

        {
            try
            {
                dataGridView1.Rows.Clear();

                foreach (var articxSurcal in nuevaAsociacion)
                {
                    if (articxSurcal != null)
                    {
                        dataGridView1.Rows.Add(
                            articxSurcal.articulos.ID,
                            articxSurcal.articulos.Descripcion,
                            articxSurcal.articulos.Nombre,
                            articxSurcal.articulos.Marca,
                            articxSurcal.Cantidad);
                    }
                }

            }
            catch (Exception e)
            {
                MessageBox.Show("Ocurrió un error al cargar los artículos: " + e.Message);
                {

                }
            }
        }

    }
}
