﻿using CapaAccesoDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmConsultarArticulo : Form
    {
        public frmConsultarArticulo()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void CargarArticulos(Articulos[] articulos)
        {


            try
            {


                dataGridView1.Rows.Clear();

                foreach (var articulo in articulos)
                {
                    if (articulo != null)
                    {

                        dataGridView1.Rows.Add(articulo.ID, 
                            articulo.Descripcion,
                            articulo.Nombre, 
                            articulo.Marca,
                            articulo.Activo);

                    }

                }

            }
            catch (Exception e)
            {
                MessageBox.Show("Ocurrió un error al cargar los artículos: " + e.Message);
            }

        }

        private void frmConsultarArticulo_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}