﻿namespace CapaPresentacion
{
    partial class frmrRegistrarAdministrador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panel1 = new Panel();
            fechaNacimiento = new DateTimePicker();
            textIdentificacion = new TextBox();
            textNombre = new TextBox();
            textPrimerApelli = new TextBox();
            textSegundoApelli = new TextBox();
            label6 = new Label();
            label5 = new Label();
            fechaIngreso = new DateTimePicker();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            button2 = new Button();
            errorProvider1 = new ErrorProvider(components);
            button1 = new Button();
            label8 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(fechaNacimiento);
            panel1.Controls.Add(textIdentificacion);
            panel1.Controls.Add(textNombre);
            panel1.Controls.Add(textPrimerApelli);
            panel1.Controls.Add(textSegundoApelli);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(fechaIngreso);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(142, 69);
            panel1.Name = "panel1";
            panel1.Size = new Size(388, 307);
            panel1.TabIndex = 0;
            // 
            // fechaNacimiento
            // 
            fechaNacimiento.Location = new Point(164, 203);
            fechaNacimiento.Name = "fechaNacimiento";
            fechaNacimiento.Size = new Size(200, 23);
            fechaNacimiento.TabIndex = 12;
            fechaNacimiento.Value = new DateTime(2024, 10, 2, 20, 56, 56, 0);
            // 
            // textIdentificacion
            // 
            textIdentificacion.Location = new Point(164, 36);
            textIdentificacion.Name = "textIdentificacion";
            textIdentificacion.Size = new Size(200, 23);
            textIdentificacion.TabIndex = 11;
            // 
            // textNombre
            // 
            textNombre.Location = new Point(164, 77);
            textNombre.Name = "textNombre";
            textNombre.Size = new Size(200, 23);
            textNombre.TabIndex = 10;
            // 
            // textPrimerApelli
            // 
            textPrimerApelli.Location = new Point(164, 119);
            textPrimerApelli.Name = "textPrimerApelli";
            textPrimerApelli.Size = new Size(200, 23);
            textPrimerApelli.TabIndex = 9;
            // 
            // textSegundoApelli
            // 
            textSegundoApelli.Location = new Point(164, 167);
            textSegundoApelli.Name = "textSegundoApelli";
            textSegundoApelli.Size = new Size(200, 23);
            textSegundoApelli.TabIndex = 8;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(27, 253);
            label6.Name = "label6";
            label6.Size = new Size(96, 15);
            label6.TabIndex = 7;
            label6.Text = "Fecha de Ingreso";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(27, 209);
            label5.Name = "label5";
            label5.Size = new Size(119, 15);
            label5.TabIndex = 6;
            label5.Text = "Fecha de Nacimiento";
            // 
            // fechaIngreso
            // 
            fechaIngreso.Location = new Point(164, 247);
            fechaIngreso.Name = "fechaIngreso";
            fechaIngreso.Size = new Size(200, 23);
            fechaIngreso.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(27, 167);
            label4.Name = "label4";
            label4.Size = new Size(101, 15);
            label4.TabIndex = 3;
            label4.Text = "Segundo Apellido";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(27, 122);
            label3.Name = "label3";
            label3.Size = new Size(89, 15);
            label3.TabIndex = 2;
            label3.Text = "Primer Apellido";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(27, 80);
            label2.Name = "label2";
            label2.Size = new Size(51, 15);
            label2.TabIndex = 1;
            label2.Text = "Nombre";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(27, 44);
            label1.Name = "label1";
            label1.Size = new Size(79, 15);
            label1.TabIndex = 0;
            label1.Text = "Identificación";
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ButtonShadow;
            button2.Font = new Font("Arial Rounded MT Bold", 12F);
            button2.Location = new Point(142, 409);
            button2.Name = "button2";
            button2.Size = new Size(109, 52);
            button2.TabIndex = 4;
            button2.Text = "Registrar";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click_1;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ButtonShadow;
            button1.Font = new Font("Arial Rounded MT Bold", 12F);
            button1.Location = new Point(421, 409);
            button1.Name = "button1";
            button1.Size = new Size(109, 52);
            button1.TabIndex = 5;
            button1.Text = "Regresar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.FlatStyle = FlatStyle.Popup;
            label8.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.Highlight;
            label8.Location = new Point(238, 24);
            label8.Name = "label8";
            label8.Size = new Size(200, 18);
            label8.TabIndex = 7;
            label8.Text = "Registrar Administrador";
            label8.TextAlign = ContentAlignment.TopCenter;
            // 
            // frmrRegistrarAdministrador
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(691, 573);
            Controls.Add(label8);
            Controls.Add(button1);
            Controls.Add(button2);
            Controls.Add(panel1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "frmrRegistrarAdministrador";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "fmrRegistrarAdministrador";
            Load += frmrRegistrarAdministrador_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textIdentificacion;
        private TextBox textNombre;
        private TextBox textPrimerApelli;
        private TextBox textSegundoApelli;
        private Button button2;
        private ErrorProvider errorProvider1;
        private DateTimePicker fechaNacimiento;
        private DateTimePicker fechaIngreso;
        private Button button1;
        private Label label8;
    }
}