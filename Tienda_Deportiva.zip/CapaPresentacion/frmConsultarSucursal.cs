﻿using CapaAccesoDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmConsultarSucursal : Form
    {
        public frmConsultarSucursal()
        {
            InitializeComponent();
        }

        private void frmConsultarSucursal_Load(object sender, EventArgs e)
        {

        }


        public void IngresarSucursales(Sucursal[] sucursal)
        {
            try
            {
                dataGridView1.Rows.Clear();
  
                    foreach (var sucurs in sucursal)
                    {
                    if (sucurs != null)
                    {
                        dataGridView1.Rows.Add(
                        sucurs.IdSucursal,
                        sucurs.NombreSucursal,
                        sucurs.NombreAdmin,
                        sucurs.DireccionSucursal,
                        sucurs.TelefoSuculsal,
                        sucurs.Activo);

                    }

                }
            }
            catch (Exception xe)
            {

                MessageBox.Show($"Ocurrió un error al cargar las sucursales: {xe.Message}\nDetalles: {xe.StackTrace}");
            }
        }

        private void BtnReg_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}

