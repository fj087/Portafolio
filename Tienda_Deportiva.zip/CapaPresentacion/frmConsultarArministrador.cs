﻿using CapaAccesoDatos;
using CapaEntidades;
using CapaLogicaNegocio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class frmConsultarArministrador : Form
    {
        public frmConsultarArministrador()
        {
            InitializeComponent();
        }

        private void frmrConsultarArministrador_Load(object sender, EventArgs e)
        {

        }
        public void IngresarAdministradores(Administrador[] administrador)
        {
            try
            {
                dataGridView1.Rows.Clear();

                foreach (var admin in administrador)
                {
                    if (admin != null)
                    {


                        dataGridView1.Rows.Add(admin.Identificacion,
                        admin.NombreAdmin,
                        admin.PrimerApellido, 
                        admin.SegundoApellido, 
                        admin.FechaCumpleaños.ToString("d"), 
                        admin.FechaIngreso.ToString("d"));

                    }

                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Ocurrió un error al cargar los artículos: " + e.Message);
                {

                }
            }
        }

        private void BtnReg_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}