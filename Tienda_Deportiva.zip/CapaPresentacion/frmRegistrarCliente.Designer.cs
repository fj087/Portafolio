﻿namespace CapaPresentacion
{
    partial class frmRegistrarCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panel1 = new Panel();
            texid = new TextBox();
            label6 = new Label();
            dateTimeFechaNacimiento = new DateTimePicker();
            comboBoxActivo = new ComboBox();
            textsegundoApellid = new TextBox();
            textprimerApellid = new TextBox();
            textnombre = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            errorProvider1 = new ErrorProvider(components);
            buttRegresar = new Button();
            ButtonRegistar = new Button();
            label8 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackgroundImageLayout = ImageLayout.None;
            panel1.Controls.Add(texid);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(dateTimeFechaNacimiento);
            panel1.Controls.Add(comboBoxActivo);
            panel1.Controls.Add(textsegundoApellid);
            panel1.Controls.Add(textprimerApellid);
            panel1.Controls.Add(textnombre);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(129, 92);
            panel1.Name = "panel1";
            panel1.Size = new Size(436, 260);
            panel1.TabIndex = 0;
            // 
            // texid
            // 
            texid.Location = new Point(191, 26);
            texid.Name = "texid";
            texid.Size = new Size(210, 23);
            texid.TabIndex = 12;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(26, 34);
            label6.Name = "label6";
            label6.Size = new Size(18, 15);
            label6.TabIndex = 11;
            label6.Text = "ID";
            // 
            // dateTimeFechaNacimiento
            // 
            dateTimeFechaNacimiento.Location = new Point(191, 176);
            dateTimeFechaNacimiento.Name = "dateTimeFechaNacimiento";
            dateTimeFechaNacimiento.Size = new Size(210, 23);
            dateTimeFechaNacimiento.TabIndex = 10;
            // 
            // comboBoxActivo
            // 
            comboBoxActivo.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxActivo.FlatStyle = FlatStyle.Flat;
            comboBoxActivo.FormattingEnabled = true;
            comboBoxActivo.Location = new Point(191, 214);
            comboBoxActivo.Name = "comboBoxActivo";
            comboBoxActivo.Size = new Size(210, 23);
            comboBoxActivo.TabIndex = 9;
            // 
            // textsegundoApellid
            // 
            textsegundoApellid.Location = new Point(191, 137);
            textsegundoApellid.Name = "textsegundoApellid";
            textsegundoApellid.Size = new Size(210, 23);
            textsegundoApellid.TabIndex = 7;
            // 
            // textprimerApellid
            // 
            textprimerApellid.Location = new Point(191, 96);
            textprimerApellid.Name = "textprimerApellid";
            textprimerApellid.Size = new Size(210, 23);
            textprimerApellid.TabIndex = 6;
            // 
            // textnombre
            // 
            textnombre.Location = new Point(191, 59);
            textnombre.Name = "textnombre";
            textnombre.Size = new Size(210, 23);
            textnombre.TabIndex = 5;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(23, 222);
            label5.Name = "label5";
            label5.Size = new Size(41, 15);
            label5.TabIndex = 4;
            label5.Text = "Activo";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(23, 184);
            label4.Name = "label4";
            label4.Size = new Size(119, 15);
            label4.TabIndex = 3;
            label4.Text = "Fecha de Nacimiento";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(23, 145);
            label3.Name = "label3";
            label3.Size = new Size(101, 15);
            label3.TabIndex = 2;
            label3.Text = "Segundo Apellido";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(23, 104);
            label2.Name = "label2";
            label2.Size = new Size(89, 15);
            label2.TabIndex = 1;
            label2.Text = "Primer Apellido";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(23, 67);
            label1.Name = "label1";
            label1.Size = new Size(51, 15);
            label1.TabIndex = 0;
            label1.Text = "Nombre";
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // buttRegresar
            // 
            buttRegresar.BackColor = SystemColors.ButtonShadow;
            buttRegresar.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            buttRegresar.Location = new Point(456, 394);
            buttRegresar.Name = "buttRegresar";
            buttRegresar.Size = new Size(109, 52);
            buttRegresar.TabIndex = 0;
            buttRegresar.Text = "Regresar";
            buttRegresar.UseVisualStyleBackColor = false;
            buttRegresar.Click += buttRegresar_Click;
            // 
            // ButtonRegistar
            // 
            ButtonRegistar.BackColor = SystemColors.ButtonShadow;
            ButtonRegistar.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ButtonRegistar.Location = new Point(129, 394);
            ButtonRegistar.Name = "ButtonRegistar";
            ButtonRegistar.Size = new Size(109, 52);
            ButtonRegistar.TabIndex = 2;
            ButtonRegistar.Text = "Regristrar";
            ButtonRegistar.UseVisualStyleBackColor = false;
            ButtonRegistar.Click += Button1_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.FlatStyle = FlatStyle.Popup;
            label8.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = SystemColors.Highlight;
            label8.Location = new Point(278, 35);
            label8.Name = "label8";
            label8.Size = new Size(143, 18);
            label8.TabIndex = 8;
            label8.Text = "Registrar Cliente";
            label8.TextAlign = ContentAlignment.TopCenter;
            // 
            // frmRegistrarCliente
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(691, 473);
            Controls.Add(label8);
            Controls.Add(buttRegresar);
            Controls.Add(ButtonRegistar);
            Controls.Add(panel1);
            Name = "frmRegistrarCliente";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Registrar Cliente";
            Load += frmRegistrarCliente_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textsegundoApellid;
        private TextBox textprimerApellid;
        private TextBox textnombre;
        private Label label5;
        private DateTimePicker dateTimeFechaNacimiento;
        private ComboBox comboBoxActivo;
        private ErrorProvider errorProvider1;
        private Button buttRegresar;
        private Button ButtonRegistar;
        private Label label6;
        private TextBox texid;
        private Label label8;
    }
}