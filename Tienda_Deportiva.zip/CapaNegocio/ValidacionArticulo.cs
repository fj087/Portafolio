﻿using CapaAccesoDatos;
using CapaEntidades;
using System.Windows;

/* UNED III Cuatrimestre
 * Proyecto 1: Tienda Deportiva
 * Estudiante: Jessenia Fuentes Ruiz
 * Fecha: 06/09/2024
 * */

namespace CapaLogicaNegocio
{
    public class ValidacionArticulo
    {
        public bool CargarArticulos(Articulos newArtcID)
        {
           

            Articulos[] articulos = RegistrarArticulo.Consultar();

            for (int i = 0; i < articulos.Length; i++)

            {
                if (articulos[i] != null && articulos[i].ID == newArtcID.ID)
                {
                    MessageBox.Show("El ID ya exíte.");
                    return false;
                }
               
            }

            bool articuloIngresado = RegistrarArticulo.CargarArticulos(newArtcID);

            if (articuloIngresado)
            {
                MessageBox.Show("El artículo registrada correctamente.");
                return true;

            }
            MessageBox.Show("N0 se pudo registrar el artículo.");
            return false;

        }
    }
}