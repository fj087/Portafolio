﻿using System;
using CapaAccesoDatos;
using CapaEntidades;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Diagnostics.Eventing.Reader;
using System.ComponentModel.DataAnnotations;

namespace CapaLogicaNegocio
{
 public class ValidacionAdmin
    {
       public  bool IngresarAdministradores(Administrador newAdmin)
        {
            Administrador[] administradores = RegistrarAdministrador.Consultar();

           
            for(int i = 0; i < administradores.Length; i ++ )
            {
                if(administradores[i] != null && administradores[i].Identificacion == newAdmin.Identificacion)
                {
                    MessageBox.Show("El identificación del administrador ya existé.");
                    return false;               
                   

                }
                
              }
                         
                bool IngresoValido = RegistrarAdministrador.IngresarAdministrador(newAdmin);
                if (IngresoValido)
                {
                    MessageBox.Show("El admistrador fué ingresado correctamente.");
                    return true;

                }
                     
                return false;
            }

        }
    }

