﻿using System;
using CapaAccesoDatos;
using CapaEntidades;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace CapaLogicaNegocio
{
    public class ValidacionSucurslxArticl
    {



        public bool IngresaSucurslxArtic(ArticulosxSucursales nuevaAsociacion)
        {

            ArticulosxSucursales[] articulosxSucursales = RegistroSucursalxArticl.Consultar();
            foreach (var asociacionExistente in articulosxSucursales)
            {
                if (asociacionExistente != null && asociacionExistente.Equals(nuevaAsociacion))
                {
                    MessageBox.Show("La sucursal ya existe para este artículo.");
                    return false; // Cambiado a false para reflejar un error
                }
                else
                {
                    return true;
                }
            }
        
    
            bool IngresoSucurlsa = RegistroSucursalxArticl.IngresaSucurslxArtic(nuevaAsociacion);
            if (IngresoSucurlsa)
            {
                MessageBox.Show("Sucursal ingresada exitosamente.");
                return true;
            }
        
        MessageBox.Show("No se pudo registrar la sucursal.");
                return false;
            }
}}

