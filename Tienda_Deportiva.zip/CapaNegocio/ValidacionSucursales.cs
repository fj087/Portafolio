﻿using System;
using CapaAccesoDatos;
using CapaEntidades;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace CapaLogicaNegocio
{
    public  class ValidacionSucursales
    {
        /// <summary>
        /// Método encargado de validar y registrar las nuevas sucursales conel método que es público
        ///  y va devolver un valor booleano true/false 
        /// </summary>
        /// <param name="newSucursal"></param>
        /// <returns></returns>
        public bool IngresarSucursales(Sucursal newSucursal) {

            //Esta parte del codigo consulta todas las sucursales almacenadas y verifica que no se repitan los IdSucursal
            Sucursal[] sucursal = RegistroSucursal.Consultar();

            for (int i = 0; i < sucursal.Length; i++)
            {

                if (sucursal[i] != null && sucursal[i].IdSucursal == newSucursal.IdSucursal)
                {
                    MessageBox.Show("El ID ya existé.");
                    return false;
                }
             
                
               }

       
            //Esta parte del código llama al método IngresarSucursales y agregar la nueva sucursal al arreglo de sucursuales
            bool registroExito = RegistroSucursal.IngresarSucursales(newSucursal);
            if(registroExito)
            {
                MessageBox.Show("Sucursal ingresada exitosamente.");
                return true;
            }
            MessageBox.Show("No se pudo registrar la sucursal.");
            return false;

        }
    }
}
