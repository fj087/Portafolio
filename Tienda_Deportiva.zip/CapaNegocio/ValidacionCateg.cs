﻿using CapaAccesoDatos;
using CapaEntidades;
using System.Windows;

/* UNED III Cuatrimestre
 * Proyecto 1: Tienda Deportiva
 * Estudiante: Jessenia Fuentes Ruiz
 * Fecha: 06/09/2024
 * */

namespace CapaLogicaNegocio
{
    public class ValidacionCateg
    {

        public bool CargarCategorias(Categorias newCateg)
        {

            bool categIngresada = false;

            Categorias[] categorias = RegistroCat.Consultar();

            for (int i = 0; i < categorias.Length; i++)
            {
                if (categorias[i] != null && categorias[i].ID == newCateg.ID)
                {

                    MessageBox.Show("El ID ya exite");
                    categIngresada = true;
                    break;
                }
            }
            if (categIngresada)
            {
                return false;
            }
            else
            {
                bool registroExitoso = RegistroCat.CargarCategorias(newCateg);
                if (registroExitoso)
                {
                    MessageBox.Show("Categoría registrada correctamente.");
                    return true;
                }


                return false;

            }

        }


    }
}