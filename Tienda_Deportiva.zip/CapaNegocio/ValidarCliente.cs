﻿using System;
using CapaAccesoDatos;
using CapaEntidades;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace CapaLogicaNegocio
{
    public class ValidarCliente
    {

        public  bool IngresarClientes(Cliente newClientes)
        {
            Cliente[] clientes = RegistroCliente.Consultar();

            for (int i = 0; i < clientes.Length; i++)
            {
                if (clientes[i] != null && clientes[i].ID == newClientes.ID)
                {
                    MessageBox.Show("El ID cliente ya existé.");
                    return false;
                }
            }
            //Esta parte del código llama al método IngresarSucursales y agregar la nueva sucursal al arreglo de sucursuales
            bool IngreseCliente = RegistroCliente.IngresarClientes(newClientes);
            if (IngreseCliente)
            {
                MessageBox.Show("Cliente ingresado exitosamente.");
                return true;

            }
            MessageBox.Show("No se pudo registrar la sucursal.");
            return false;
        }
    }
}