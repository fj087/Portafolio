﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class Sucursal : Administrador
    {
        public int IdSucursal { get; set; }
        public string NombreSucursal { get; set; }
        public string NombreAdmin { get; set; }

        public string DireccionSucursal { get; set; }
        public long TelefoSuculsal { get; set; } //long permite almacer números mas grandes que int
        public bool Activo { get; set; }


        public override bool Equals(object obj)
        {
            if (obj is Sucursal otroArticulo)
            {
                return IdSucursal == otroArticulo.IdSucursal; // Compara por ID
            }
            return false; // No son iguales
        }

        public override string ToString()
        {
            return NombreSucursal; // Mostrar nombre en el ComboBox
        }
    }
}



