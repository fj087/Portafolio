/* UNED III Cuatrimestre
 * Proyecto 1: Tienda Deportiva
 * Estudiante: Jessenia Fuentes Ruiz
 * Fecha: 06/09/2024
 * */

namespace CapaEntidades
{
    public class Categorias

    {
        public int ID { get; set; }
        public string Nombre { get; set; }
        public string Descrip { get; set; }
        
        public override string ToString()
        {
            return $"ID: {ID}, Nombre: {Nombre}, Descripci�n: {Descrip}";
        }
    }
}
