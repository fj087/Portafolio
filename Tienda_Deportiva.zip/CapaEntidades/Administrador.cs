﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* UNED III Cuatrimestre
 * Proyecto 1: Tienda Deportiva
 * Estudiante: Jessenia Fuentes Ruiz
 * Fecha: 06/09/2024
 * */
namespace CapaEntidades
{

   
   public  class Administrador
    {
      
        public int Identificacion { get; set; }
        public string NombreAdmin { get; set; }  
        public string PrimerApellido { get; set; }  
        public string SegundoApellido {  get; set; }
        public DateTime FechaCumpleaños { get; set; }
        public DateTime FechaIngreso { get; set; }

        

        public override string ToString()
        {
            return $"Identificacion: {Identificacion}, Nombre: {NombreAdmin}, Primer Apellido: {PrimerApellido}, Segundo Apellido: {SegundoApellido}, Fecha de Nacimiento: {FechaCumpleaños}, Fecha de Ingreso: {FechaIngreso} ";
        }

      

    }
}
