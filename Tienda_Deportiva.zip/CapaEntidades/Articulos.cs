﻿/* UNED III Cuatrimestre
 * Proyecto 1: Tienda Deportiva
 * Estudiante: Jessenia Fuentes Ruiz
 * Fecha: 06/09/2024
 * */

namespace CapaEntidades
{
    public class Articulos : Categorias
    {
        public int ID  { get; set; }
        public string Descripcion { get; set; }
        public string Marca { get; set; }
      
        public bool Activo { get; set; }

        public override bool Equals(object obj)
        {
            if (obj is Articulos otroArticulo)
            {
                return ID == otroArticulo.ID; // Compara por ID
            }
            return false; // No son iguales
        }

        public override int GetHashCode()
        {
            return ID.GetHashCode(); // Retorna el hash del ID
        }

        public override string ToString()
        {
            return $"ID: {ID}, Descripción: {Descripcion}, Marca: {Marca}, Activo: {(Activo ? "True" : "False")}, Categoría: {Nombre}";
        }
    }
}
