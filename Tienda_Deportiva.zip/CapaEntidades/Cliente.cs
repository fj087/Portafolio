﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class Cliente
    {
        public string Nombre { get; set; }
        public int ID {  get; set; }  

        public string PrimerApellido { get; set; }  
        public string SegundoApellido { get; set; } 
        public DateTime FechaNacimiento { get; set; }   
        public bool Activo {  get; set; }

        public override string ToString()
        {
            return $" ID:, {ID}, Nombre: {Nombre}, Primer Apellido: {PrimerApellido}, Segundo Apellido: {SegundoApellido}, Fecha de Nacimiento: {FechaNacimiento}, Activo: {(Activo ? "Sí" : "No")}";
        }
    }
}
