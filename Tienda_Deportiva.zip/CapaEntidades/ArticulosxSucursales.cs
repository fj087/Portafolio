﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace CapaEntidades
{
    public class ArticulosxSucursales : Articulos
    {
        public Sucursal sucursal { get; set; }
        public Articulos articulos { get; set; }
       
     
        public int Cantidad { get; set; }

        public ArticulosxSucursales(Sucursal sucursal, Articulos articulo , int cantidad)
        {
            this.sucursal = sucursal;
            this.articulos = articulo;
            Cantidad = cantidad;
        }
        // Método para validar la asociación
        public bool ValidarAsociacion(out string mensaje)
        {
            if (sucursal == null)
            {
                mensaje = "La sucursal no puede ser nula.";
                return false;
            }

            if (articulos == null)
            {
                mensaje = "El artículo no puede ser nulo.";
                return false;
            }

            if (Cantidad <= 0)
            {
                mensaje = "La cantidad debe ser mayor que cero.";
                return false;
            }

            mensaje = "Validación exitosa.";
            return true;
        }

        public override string ToString()
        {
            return $"Sucursal: {sucursal.NombreSucursal} Artículo {articulos.Descripcion}, Cantidad: {Cantidad}";
        }

     

    }
}
